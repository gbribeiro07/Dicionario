const modal1 = document.querySelector('.modal1');
const blur = document.querySelector('.blur');
const botao = document.querySelectorAll('.button');
const titulo1 = document.querySelector('.título_modal');
const titulo1p = document.querySelector('.título_modalp');
const texto1c = document.querySelector('#contotxt');
const text1 = document.querySelector('#texto');
const text1p = document.querySelector('#textop');
const titulo2 = document.querySelector('.título_modal');
const titulo2p = document.querySelector('.título_modalp');
const texto2c = document.querySelector('#contotxt');
const text2 = document.querySelector('#texto');
const text2p = document.querySelector('#textop');
const titulo3 = document.querySelector('.título_modal');
const titulo3p = document.querySelector('.título_modalp');
const texto3c = document.querySelector('#contotxt');
const text3 = document.querySelector('#texto');
const text3p = document.querySelector('#textop');
const titulo4 = document.querySelector('.título_modal');
const titulo4p = document.querySelector('.título_modalp');
const texto4c = document.querySelector('#contotxt');
const text4 = document.querySelector('#texto');
const text4p = document.querySelector('#textop');
const titulo5 = document.querySelector('.título_modal');
const titulo5p = document.querySelector('.título_modalp');
const texto5c = document.querySelector('#contotxt');
const text5 = document.querySelector('#texto');
const text5p = document.querySelector('#textop');
const titulo6 = document.querySelector('.título_modal');
const titulo6p = document.querySelector('.título_modalp');
const texto6c = document.querySelector('#contotxt');
const text6 = document.querySelector('#texto');
const text6p = document.querySelector('#textop');
const titulo7 = document.querySelector('.título_modal');
const titulo7p = document.querySelector('.título_modalp');
const texto7c = document.querySelector('#contotxt');
const text7 = document.querySelector('#texto');
const text7p = document.querySelector('#textop');
const titulo8 = document.querySelector('.título_modal');
const titulo8p = document.querySelector('.título_modalp');
const texto8c = document.querySelector('#contotxt');
const text8 = document.querySelector('#texto');
const text8p = document.querySelector('#textop');
const titulo9 = document.querySelector('.título_modal');
const titulo9p = document.querySelector('.título_modalp');
const texto9c = document.querySelector('#contotxt');
const text9 = document.querySelector('#texto');
const text9p = document.querySelector('#textop');
const titulo10 = document.querySelector('.título_modal');
const titulo10p = document.querySelector('.título_modalp');
const texto10c = document.querySelector('#contotxt');
const text10 = document.querySelector('#texto');
const text10p = document.querySelector('#textop');
const seta = document.querySelector('.seta');
const conto = document.querySelector('.dialogo');
const xis = document.querySelector('#xis');
const xis1 = document.querySelector('#xis1');


const audioEn = document.querySelector('#audio_icon');
const audioPt = document.querySelector('#audio_icon2');

const Within = new Audio('assets/Within.mp3');
const Overwise = new Audio('assets/Overwise.mp3');
const Improve = new Audio('assets/Improve.mp3');
const Nor = new Audio('assets/Nor.mp3');
const Growth = new Audio('assets/Growth.mp3');
const Recognizable = new Audio('assets/Recognizable.mp3');
const Although = new Audio('assets/Although.mp3');
const Reborn = new Audio('assets/Reborn.mp3');
const Magnesium = new Audio('assets/Magnesium.mp3');
const Apigenin = new Audio('assets/Apigenin.mp3');

const Dentro = new Audio('assets/Dentro.mp3');
const Excessivamente = new Audio('assets/Excessivamente.mp3');
const Melhorar = new Audio('assets/Melhorar.mp3');
const Nem = new Audio('assets/Nem.mp3');
const Crescimento = new Audio('assets/Crescimento.mp3');
const Reconhecível = new Audio('assets/Reconhecível.mp3');
const Embora = new Audio('assets/Embora.mp3');
const Renascido = new Audio('assets/Renascido.mp3');
const Magnésio = new Audio('assets/Magnésio.mp3');
const Apigenina = new Audio('assets/Apigenina.mp3');

let i = 0
let audioIngles
let audioPortugues

xis1.addEventListener('click', (e) =>{
    e.preventDefault();
    modal1.style.visibility = 'hidden'
    blur.style.visibility = 'hidden'
})

botao[0].addEventListener('click', (e) =>{
    e.preventDefault();

    i = 1

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo1.textContent = "Within"
    text1.textContent = "Preposition: inside (something).   Adverb: inside; indoors."
    titulo1p.textContent = "Dentro"
    text1p.textContent = "Advérbio: interior;interiormente; adentro."
    texto1c.textContent = "E, em torno de átimos de segundo, Dáimon alcançou o que ele tanto almejou a sua vida inteira: as estrelas! Elas tocaram-no com todo o seu calor e ele se decompôs em mil pedaços luminosos. Fundindo-se com o Eterno, ele, espírito infinito, renasceu como pura luz na imensidão do inefável, o mais belo dos reinos."
})

botao[1].addEventListener('click', (e) =>{
    e.preventDefault();

    i = 2

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo2.textContent = "Overwise"
    text2.textContent = "Adjective: excessively or unusually wise."
    titulo2p.textContent = "Excessivamente"
    text2p.textContent = "Advérbio: em demasia;de modo excessivo; sem moderação."
    texto2c.textContent = "- Vá! Melhora! Cresça! Me agarra, ó alma imortal, e adormeça no berço do amor, como se tu tivesses tido excessivas overdoses de Apigenina e Magnésio. Nem o vício, nem a apatia, eu sou a moderação. - Clamava a flauta."
    
})
botao[2].addEventListener('click', (e) =>{
    e.preventDefault();

    i = 3

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo3.textContent = "Improve"
    text3.textContent = "Verb: make or become better."
    titulo3p.textContent = "Melhorar"
    text3p.textContent = "Verbo: aperfeiçoar;produzir ou adquirir melhoria; mudar algo, alguém ou a si mesmo para um estado melhor."
    texto3c.textContent = "- Vá! Melhora! Cresça! Me agarra, ó alma imortal, e adormeça no berço do amor, como se tu tivesses tido excessivas overdoses de Apigenina e Magnésio. Nem o vício, nem a apatia, eu sou a moderação. - Clamava a flauta."
    
})
botao[3].addEventListener('click', (e) =>{
    e.preventDefault();

    i = 4

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo4.textContent = "Nor"
    text4.textContent = "Adjective: used before the second or further of two or more alternatives (the first being introduced by a negative such as “neither” or “not”) to indicate that they are each untrue or each do not happen; used to introduce a further negative statement."
    titulo4p.textContent = "Nem"
    text4p.textContent = "Conjunção: serve para ligar palavras e orações negativas. Advérbio: exprime negação."
    texto4c.textContent = "- Vá! Melhora! Cresça! Me agarra, ó alma imortal, e adormeça no berço do amor, como se tu tivesses tido excessivas overdoses de Apigenina e Magnésio. Nem o vício, nem a apatia, eu sou a moderação. - Clamava a flauta."
    
})
botao[4].addEventListener('click', (e) =>{
    e.preventDefault();

    i = 5

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo5.textContent = "Growth"
    text5.textContent = "Noun: the process of increasing."
    titulo5p.textContent = "Crescimento"
    text5p.textContent = "Substantivo masculino: multiplicação ou aumento em dimensão;desenvolvimento, progresso, evolução."
    texto5c.textContent = "- Vá! Melhora! Cresça! Me agarra, ó alma imortal, e adormeça no berço do amor, como se tu tivesses tido excessivas overdoses de Apigenina e Magnésio. Nem o vício, nem a apatia, eu sou a moderação. - Clamava a flauta."
    
})
botao[5].addEventListener('click', (e) =>{
    e.preventDefault();

    i = 6

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo6.textContent = "Recognizable"
    text6.textContent = "Adjective: able to be recognized or identified from previous encounters or knowledge."
    titulo6p.textContent = "Reconhecível"
    text6p.textContent = "Adjetivo de dois gêneros: passível de ser reconhecido; que se pode reconhecer facilmente."
    texto6c.textContent = "Dáimon era um ser à parte. Filho de um senhor rico (um dos mais notórios e reconhecidos homens de seu país natal) com uma mulher pobre, desde pequeno já sentia uma inclinação às estrelas, fazendo diversos estratagemas para alcançá-las. Ele tentou chegar até elas por meio de escadas, pontes, escalando montes e, enfim, de muitas formas; porém todas as suas tentativas falharam. "
    
})
botao[6].addEventListener('click', (e) =>{
    e.preventDefault();

    i = 7

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo7.textContent = "Although"
    text7.textContent = "Conjunction: in spite of the fact that; even though."
    titulo7p.textContent = "Embora"
    text7p.textContent = "Advérbio: exprime ideia de retirada. Conjunção concessiva: apesar de, enquanto, mesmo que."
    texto7c.textContent = "Apesar disso, a inclinação que Dáimon sentia pelos astros só foi crescendo cada vez mais. Em um certo dia, ele, já mais perto de sua velhice, encontrou uma flauta no alto de um promontório em meio ao oceano. Quando olhou para ela, Dáimon sentiu como se todo o seu ser estivesse sendo intensamente puxado por aquele objeto singular."
    
})
botao[7].addEventListener('click', (e) =>{
    e.preventDefault();

    i = 8

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo8.textContent = "Reborn"
    text8.textContent = "Adjective: brought back to life or activity. Having experienced a complete spiritual change."
    titulo8p.textContent = "Renascido"
    text8p.textContent = "Adjetivo: renovar-se; rejuvenecer. Nascer de novo."
    texto8c.textContent = "E, em torno de átimos de segundo, Dáimon alcançou o que ele tanto almejou a sua vida inteira: as estrelas! Elas tocaram-no com todo o seu calor e ele se decompôs em mil pedaços luminosos. Fundindo-se com o Eterno, ele, espírito infinito, renasceu como pura luz na imensidão do inefável, o mais belo dos reinos."
    
})
botao[8].addEventListener('click', (e) =>{
    e.preventDefault();

    i = 9

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo9.textContent = "Magnesium"
    text9.textContent = "Noun: the chemical element of atomic number 12, a silver-white metal of the alkaline earth series. It is used to make strong lightweight alloys, especially for the aerospace industry, and is also used in flashbulbs and pyrotechnics because it burns with a brilliant white flame."
    titulo9p.textContent = "Magnésio"
    text9p.textContent = "Substantivo masculino: elemento químico (símbolo: Mg), de número atómico 12, metal branco como a prata, muito leve, que arde ao ar com uma chama deslumbrante. "
    texto9c.textContent = "- Vá! Melhora! Cresça! Me agarra, ó alma imortal, e adormeça no berço do amor, como se tu tivesses tido excessivas overdoses de Apigenina e Magnésio. Nem o vício, nem a apatia, eu sou a moderação. - Clamava a flauta."
})
botao[9].addEventListener('click', (e) =>{
    e.preventDefault();

    i = 10

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo10.textContent = "Apigenin"
    text10.textContent = "Noun: a yellowish crystalline compound C15H10O5 occurring usually as glycosides (such as apiin) in various plants; 4, 5,7-trihydroxy-flavone."
    titulo10p.textContent = "Apigenina"
    text10p.textContent = "Substantivo masculino: ingrediente de medicamentos fitoterápicos indicados para a cicatrização de feridas na boca e de suplementos alimentares."
    texto10c.textContent = "- Vá! Melhora! Cresça! Me agarra, ó alma imortal, e adormeça no berço do amor, como se tu tivesses tido excessivas overdoses de Apigenina e Magnésio. Nem o vício, nem a apatia, eu sou a moderação. - Clamava a flauta."
    
})
seta.addEventListener('click', (e) =>{
    e.preventDefault();

    conto.style.visibility = 'visible'
})
xis.addEventListener('click', (e) =>{
    e.preventDefault();

    conto.style.visibility = 'hidden'
})

audioEn.addEventListener('mouseover', (e) =>{
    switch (i){
        case 1:
            audioIngles = Within;
            break
        case 2:
            audioIngles = Overwise;
            break
        case 3:
            audioIngles = Improve;
            break
        case 4:
            audioIngles = Nor;
            break
        case 5:
            audioIngles = Growth;
            break
        case 6:
            audioIngles = Recognizable;
            break
        case 7:
            audioIngles = Although;
            break
        case 8:
            audioIngles = Reborn;
            break
        case 9:
            audioIngles = Magnesium;
            break
        case 10:
            audioIngles = Apigenin;
            break
    }

    audioIngles.load()
    audioIngles.play()
})

audioEn.addEventListener('mouseout', (e) =>{
    
    audioIngles.pause()

})

audioPt.addEventListener('mouseover', (e) =>{
    switch (i){
        case 1:
            audioPortugues = Dentro;
            break
        case 2:
            audioPortugues = Excessivamente;
            break
        case 3:
            audioPortugues = Melhorar;
            break
        case 4:
            audioPortugues = Nem;
            break
        case 5:
            audioPortugues = Crescimento;
            break
        case 6:
            audioPortugues = Reconhecível;
            break
        case 7:
            audioPortugues = Embora;
            break
        case 8:
            audioPortugues = Renascido;
            break
        case 9:
            audioPortugues = Magnésio;
            break
        case 10:
            audioPortugues = Apigenina;
            break
    }

    audioPortugues.load()
    audioPortugues.play()
})

audioPt.addEventListener('mouseout', (e) =>{
    
    audioPortugues.pause()

})

